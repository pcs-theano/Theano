from Cython.Shadow import __version__

# Void cython.* directives (for case insensitive operating systems).
from Cython.Shadow import *
