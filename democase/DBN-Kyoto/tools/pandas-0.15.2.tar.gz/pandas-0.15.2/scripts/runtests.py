from __future__ import print_function
import os
print(os.getpid())
import nose
nose.main('pandas.core')
