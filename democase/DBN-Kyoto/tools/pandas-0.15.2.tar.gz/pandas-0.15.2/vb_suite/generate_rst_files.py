from suite import benchmarks, generate_rst_files
generate_rst_files(benchmarks)
